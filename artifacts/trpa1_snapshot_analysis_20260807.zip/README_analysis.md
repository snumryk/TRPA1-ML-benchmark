# TRPA1 raw snapshot: первинний аналіз

- Snapshot: **5528 records**, **97 assays**, **1830 unique ChEMBL molecules**.
- Старий strict dataset із 2196 records повністю міститься у snapshot.
- Додано 3332 records, але більшість із них не є новими IC50 labels.

## Що реально додалося

- KON: 1530 records
- K_OFF: 1530 records
- IC50: 174 records
- INHIBITION: 41 records
- PIC50: 40 records
- ACTIVITY: 17 records

3060 KON/K_OFF records не мають числових standard values і не придатні як labels для нашої задачі. Їх треба виключити з ML dataset.

## IC50

- Exact numeric IC50: 2208
- Right-censored (`>`): 126
- Left-censored (`<`): 9
- Not determined: 27

## Попередня evidence-оцінка за 10/30 µM

- Numeric positive evidence, після технічних quality gates: 1917 records / 1424 molecules.
- Numeric negative evidence, після технічних quality gates: 60 records / 58 molecules / 11 assays / 10 documents.
- Text `Not active`: 39 records / 31 molecules; це лише manual-review evidence.
- Молекули з одночасним positive і negative numeric evidence: 3 (CHEMBL165, CHEMBL2387060, CHEMBL5591759).

## Висновок

Snapshot успішний і значно корисніший за strict dataset. Він дав справжні censored IC50 records та textual inactivity. Але автоматично готового negative class ще немає: приблизно 58 молекул мають технічно чисте числове negative evidence, ще 31 молекула мають text-only `Not active` і потребують ручного підтвердження. Наступний крок — не писати новий великий pipeline, а вручну перевірити лише assays/records, які реально формують negative class.